function [BVals BHypo]= ASR_L_Shell(Data,ParamL,ParamSurro)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html 
% for further specifications and conditions of use. 
% References 
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012

D = size(Data,1);
M = size(Data,2);
for kkk = 1:D
    Data(kkk,:) = (Data(kkk,:)-mean(Data(kkk,:)))/std(Data(kkk,:));
end



% allocating space for surrogates
DataSur = zeros(ParamSurro.Number+1,D,M);
DataSur(1,:,:) = Data;

BVals = -1*ones(ParamSurro.Number+1,D,D);

for Di = 1:ParamSurro.Number+1    
    tic
    fprintf('L Surrog %i ',Di);
    if Di > 1
        DataSur(Di,:,:) =ASR_SurrogateMulti(Data,ParamSurro);
    end
    BVals(Di,:,:) = ASR_L(squeeze(DataSur(Di,:,1:ParamL.dsf:end)),ParamL);
    toc
end

% create a symmetrized version of the result matrix
BValsSym = -1*ones(ParamSurro.Number+1,D,D);
for Di = 1:ParamSurro.Number+1
 BValsSym(Di,:,:) = squeeze(BVals(Di,:,:))+squeeze(BVals(Di,:,:))';
end

BHypo = zeros(D,D);
for kkk1 = 1:D
    for kkk2 = 1:D
        if BValsSym(1,kkk1,kkk2) > max(BValsSym(2:end,kkk1,kkk2))
            BHypo(kkk1,kkk2) = 1;
        end
    end
end