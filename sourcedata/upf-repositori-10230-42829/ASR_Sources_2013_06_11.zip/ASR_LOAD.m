function [Data] = ASR_LOAD(wnd,focal)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html 
% for further specifications and conditions of use. 
% References 
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012

% Input 
% wnd: index of signal pair
% focal: 1 for 'focal'; 0 for 'non-focal'

if focal
    if wnd < 10
        filename = sprintf('Data_F_Ind000%i.txt',wnd);
    else
        if wnd < 100
            filename = sprintf('Data_F_Ind00%i.txt',wnd);           
        else
            if wnd < 1000
                filename = sprintf('Data_F_Ind0%i.txt',wnd);
            else
                filename = sprintf('Data_F_Ind%i.txt',wnd);
            end
        end
    end
else
    if wnd < 10
        filename = sprintf('Data_N_Ind000%i.txt',wnd);
    else
        if wnd < 100
            filename = sprintf('Data_N_Ind00%i.txt',wnd);           
        else
            if wnd < 1000
                filename = sprintf('Data_N_Ind0%i.txt',wnd);
            else
                filename = sprintf('Data_N_Ind%i.txt',wnd);
            end
        end
    end
end

Data = load(filename);
Data = Data';