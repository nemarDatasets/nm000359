function [NPE] = ASR_N(Datarec,ParamN)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html
% for further specifications and conditions of use.

% For references that describe this particular algorithm please refer to [2,3]
% and references therein.

% References
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012
% [2] Kantz H and Schreiber T, Nonlinear Time Series Analysis.
%     2nd Edition (Cambridge Univ. Press, Cambridge, UK, 2004
% [3] Andrzejak RG et al. Phys. Rev. E 64, 061907, 2001.


% we take the transpose of the data just to couple different source codes
Datarec = Datarec';

W = ParamN.Theiler;
m = ParamN.m;
tau = ParamN.tau;
k = ParamN.k;
H = ParamN.H;

NM = size(Datarec);
M = NM(1)-ParamN.Hmax;  % Number of samples
D = NM(2);           % Number of channels


embwin = (m-1)*tau;
Neff = M -embwin;

% Ncorrected(counter) is the effective number of distances in row/colum
% #counter of the distance matrix. Here the Theiler correction that skipps
% W data points has to be taken into account
Ncorrected = zeros(1,Neff);
Ncorrected(1:Neff) = Neff-(W*2+1);
for counter = 1:W
    Ncorrected(counter) = Neff-W-(counter);
    Ncorrected(Neff-counter+1) = Neff-W-(counter);
end;

% Allocate matrices
Hdistances =zeros(Neff,Neff,D,'single');
Hindexes = zeros(Neff,Neff,D,'int16');

% Determine distance matrices
for counter3 = 1:D
    for counter1 = embwin+1:embwin+1+tau
        for counter2 = counter1+1+W:M
            distA = 0;
            for index = -embwin:tau:0;
                distA = distA+(Datarec(counter1+index,counter3)-Datarec(counter2+index,counter3))^2; % X
            end
            Hdistances(counter1-embwin,counter2-embwin,counter3)=distA;
            Hdistances(counter2-embwin,counter1-embwin,counter3)=distA;
        end
    end
    for counter1 = embwin+2+tau:M
        for counter2 = counter1+1+W:M
            Hdistances(counter1-embwin,counter2-embwin,counter3)= Hdistances(counter1-embwin-tau,counter2-embwin-tau,counter3)-(Datarec(counter1-embwin-tau,counter3)-Datarec(counter2-embwin-tau,counter3))^2+(Datarec(counter1,counter3)-Datarec(counter2,counter3))^2;
            Hdistances(counter2-embwin,counter1-embwin,counter3)=Hdistances(counter1-embwin,counter2-embwin,counter3);
        end
    end
end

% overwrite zeros that were skipped due to the Theiler correction with an
% arbitrary high number. IMPORTANT: This number must be higher than the
% highest distance expected in the distance matrix
highnumber = 1e99;
Hdistances(Hdistances==0)=highnumber;

NPE = zeros(D,1);
NPEs = zeros(Neff,1);

for c3 = 1:D
    [~, Hindexes(:,:,c3)] = sort(Hdistances(:,:,c3));
    for j = embwin+1:M
        Ydiff = Datarec(j+H,c3)-mean(Datarec(Hindexes(1:k,j-embwin,c3)+H+embwin,c3));
        NPEs(j-embwin) = Ydiff^2;
    end;
    NPE(c3) = sqrt(squeeze(mean(NPEs))); % across datapoints
end
end

