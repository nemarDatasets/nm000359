function [CVals AVals FVals SHypo]= ASR_S_Shell(Data,ParamS,ParamSurro)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html
% for further specifications and conditions of use.
% For a reference that describes this particular algorithm please refer to [1,2]
% References
% [1] Andrzejak RG, Schindler K and Rummel C, Phys Rev E 86, 046206, 2012
% [2] Andrzejak RG et al. Phys Rev E 64, 061907, 2001

D = size(Data,1);   % number of channels
M = size(Data,2);   % number of samples
for kkk = 1:D
    Data(kkk,:) = (Data(kkk,:)-mean(Data(kkk,:)))/std(Data(kkk,:));
end

% cross-correlation part
% allocating space for surrogates
DataSur = zeros(ParamSurro.Number+1,D,M);
DataSur(1,:,:) = Data;

CVals = zeros(ParamSurro.Number+1,D,D);
AVals = zeros(ParamSurro.Number+1,D);
FVals = zeros(ParamSurro.Number+1,D);


for Di = 1:ParamSurro.Number+1
    tic
    fprintf('S Surrog %i ',Di);
    if Di > 1
        DataSur(Di,:,:) =ASR_SurrogateMulti(Data,ParamSurro);
    end
    CVals(Di,:,:) = ASR_C(squeeze(DataSur(Di,:,:)),ParamS);
    toc
    
end

% frequency and amplitude part
DataSur = Data;
for Di = 1:ParamSurro.Number+1
    tic
    fprintf('A F Surrog %i ',Di);
    if Di > 1
        for kkk = 1:D
            DataSur(kkk,:) = ASR_SurrogateUni(Data(kkk,:),ParamSurro);
        end
    end
    [AVals(Di,:) FVals(Di,:)] = ASR_AF(DataSur,ParamS);
    
    toc
end

CMatrix = zeros(D,D);
AVector = zeros(D,1);
FVector = zeros(D,1);
SHypo = zeros(D,D);

for kkk1 = 1:D
    if AVals(1,kkk1) > max(AVals(2:end,kkk1))
        AVector(kkk1) = 1;
    end
    if FVals(1,kkk1) > max(FVals(2:end,kkk1))
        FVector(kkk1) = 1;
    end
    for kkk2 = 1:D
        if CVals(1,kkk1,kkk2) > max(CVals(2:end,kkk1,kkk2))
            CMatrix(kkk1,kkk2) = 1;
        end
    end
end

for kkk1 = 1:D
    for kkk2 = 1:D
        if CMatrix(kkk1,kkk2)+AVector(kkk1)+AVector(kkk2)+FVector(kkk1)+FVector(kkk2) >0
            SHypo(kkk1,kkk2) = 1;
        end
    end
end
