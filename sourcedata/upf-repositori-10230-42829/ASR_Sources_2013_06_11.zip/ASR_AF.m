function [AVector FVector] = ASR_AF(Data,ParamS)

Segm = ParamS.Segments;
D = size(Data,1);   % number of channels
M = size(Data,2);   % number of samples
FVector = zeros(D,1);
AVector = zeros(D,1);


for kkk = 1:D
    Data1D = Data(kkk,:);
    ASPN = zeros(1,Segm);
    AVNS = zeros(1,Segm);
    
    SegmL = round(M/Segm);
    for Segc = 1:Segm
        DSegm= Data1D((Segc-1)*SegmL+1:Segc*SegmL);
        [Pxx, W] = periodogram(DSegm,[],SegmL);
        ASPN(Segc) = mean(W.*Pxx)/mean(Pxx);
        AVNS(Segc) = mean(abs(DSegm(:)-mean(DSegm)));
        
    end
    
    FVector(kkk) = mean(abs(ASPN(:)-mean(ASPN)));
    AVector(kkk) = mean(abs(AVNS(:)-mean(AVNS)));
    
end

