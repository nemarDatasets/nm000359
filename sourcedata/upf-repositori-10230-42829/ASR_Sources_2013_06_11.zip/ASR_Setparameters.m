function [ParamFilter ParamN ParamL ParamS ParamSurro] = ASR_Setparameters
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html 
% for further specifications and conditions of use. 
% References 
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012


% In the following we set the parameter to the values used in Section III
% of reference [1]. 

% Parameters of the nonlinear prediction error N
ParamN.dsf = 4;          % downsamplingfactor
ParamN.m = 8;            % embedding dimension m
ParamN.tau = 4;          % time delay tau
ParamN.k = 5;            % number of nearest neighbors k
ParamN.Theiler = 19;     % Theiler correction W
ParamN.H = 4;            % prediction horizon H
ParamN.Hmax = 32;        % maximal prediction horizon H [*]

% [*] For the calculation of the nonlinear prediction error, reference 
% points closer than one prediction horizon to the end of the signal have 
% to be excluded Otherwise, one would make predictions 
% beyond the end of the signal. In Appendix A of the reference [1] we used 
% prediction horizons of H = [1,2,4,8,16,32]. To use the same data across
% these parameters, the parameter ParamN.Hmax = 32 is used. In case, you
% use only one fixed prediction horizon, you should set ParamN.Hmax to the
% value of ParamN.H.


% Parameters of the nonlinear interdependence measure L
ParamL.dsf = 4;          % downsamplingfactor
ParamL.m = 8;            % embedding dimension m
ParamL.tau = 4;          % time delay tau
ParamL.k = 5;            % number of nearest neighbors k
ParamL.Theiler = 19;     % Theiler correction W

% Parameters of the stationarity test S
ParamS.Segments = 16;   % Number of segments

% Parameter of the surrogates
ParamSurro.Number = 19;        % Number of surrogates
ParamSurro.MaxIter = 120;      % Maximal Iterations
ParamSurro.type = 1;           % 1: perfect amplitudes, 2: perfect periodogram


% Parameter of the filter [**]
ParamFilter.detrend = 1;        % Apply detrending before filtering [***]
ParamFilter.lorderp = 8;        % order of low-pass
ParamFilter.lcp = 40;           % low-pass cut-off freq [Hz]
ParamFilter.slp = 46.5;         % low band-stop [Hz]
ParamFilter.shp = 53.5;         % high band-stop [Hz]
ParamFilter.sorderp = 40;       % order band-stop

%[**] The data as provided on the page is sampled at 512 HZ and band-pass
% filtered between 0.5Hz and 150Hz. As described in the manuscript, we
% applied an additional low-pass Butterworth-filter with a cut-off frequency
% of 40Hz. Furthermore, we applied a stop-band filter between 46.5HZ and
% 53.5Hz to supress 50Hz line noise. Note however, that this stop-band
% filter has almost no effect, since the filter function the low-pass at 40Hz 
% already very small at 50Hz. So, the low-pass already supresses the line
% noise.
% Important note: this filtering is the first step of analysis, and the type of
% pre-processing should be adjusted to the specific type of data under
% analysis.

%[***] This calls the Matlab function detrend.m 
