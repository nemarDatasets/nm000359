function Data=ASR_Filter(Data, fs, ParamFilter)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html 
% for further specifications and conditions of use. 
% References 
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012
D = size(Data,1);
for kkk = 1:D
    if ParamFilter.detrend
        Data(kkk,:) = detrend(Data(kkk,:));
    end
    Data(kkk,:) = ASR_Butter(Data(kkk,:),fs,ParamFilter);


end
