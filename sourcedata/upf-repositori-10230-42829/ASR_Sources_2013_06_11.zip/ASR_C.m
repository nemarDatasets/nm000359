function [ResStatXC] = ASR_C(Data,ParamS)

D = size(Data,1);
M = size(Data,2);
ResStatXC = zeros(D,D);
AResStatXC=zeros(ParamS.Segments,D,D);

Segm=ParamS.Segments;
SegmL = round(M/Segm);

for Segc = 1:Segm
    DSegm= Data(:,(Segc-1)*SegmL+1:Segc*SegmL);
    AResStatXC(Segc,:,:) = corrcoef(DSegm');
end

for i = 1:D
    for j = 1:D
        ResStatXC(i,j) = mean(abs(AResStatXC(:,i,j)-mean(AResStatXC(:,i,j))));
    end
end

end