function [UVals UHypo BVals BHypo CVals AVals FVals SHypo] = ASR_Main(Data)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html 
% for further specifications and conditions of use. 
% Reference: 
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012


% Expected INPUT:
% Please note that the source code provided here allows to carry out the
% calculations for more than two channels. The input 'Data' must be a matrix of 
% dimension [D x M]. Here D is the number of channels, and M is the number 
% of samples for each channel. For the bivariate case we have D = 2.
% As an example we load the 500-th focal signal pair below. If you want to
% analyze the data provided as input argument to this function, you should 
% erase the line 'Data =  ASR_LOAD(500,1);' below. 


% OUTPUT
% UVals
    % Matrix of dimension [(ParamSurro.Number+1) x D]
    % UVals(1,:) nonlinear prediction error results for the original D channels.
    % UVals(2,:) ,:) nonlinear prediction error results for the first surrogates for all D channels
    % ...
    % UVals(ParamSurro.Number+1,:) ,:) nonlinear prediction error results for the (ParamSurro.Number)-th surrogates for all D channels
    
% UHypo
    % Vector of dimension [D x 1]
    % The i-th element is 1, if the randomness test was rejected for the i-th
    % channel. If the randomness test was not rejected for the i-t channel, 
    % the i-th element is 0.
 
% BVals
    % Matrix of dimension [(ParamSurro.Number+1) x D x D]
    % BVals(1,:,:) nonlinear interdependence measure results for the original D x D channels.
    % BVals(2,:,:) nonlinear interdependence measure results for the first surrogates for all D x D channels
    % ...
    % BVals(ParamSurro.Number+1,:,:) nonlinear interdependence measure results for the (ParamSurro.Number)-th surrogates for all D x D channels
    
    % Here entry BVals(1,i,j) corresponds to L(i|j) for the original channels i
    % and j. This value is different from BVals(1,j,i), which 
    % corresponds to L(j|i) for the original channels i and j. 
    % See Reference [2] in ASR_L. for further details. 
    % For the nonlinear independence test we at first symmetrize these 
    % matrices (See comment in ASR_L_Shell.m) 
    
% BHypo
    % Symmetric matrix of dimension [D x D]
    % The (i,j)-th element is 1, if the nonlinear independence test 
    % was rejected for the channel pair with index i and j. 
    % If the nonlinear interdependence test was not rejected for the pair 
    % (i,j), the element is 0.
    
% CVals    
    % Symmetric matrix of dimension [(ParamSurro.Number+1) x D x D]
    % CVals(1,:,:) correlation-stationarity results for the original D x D channels.
    % CVals(2,:,:) correlation-stationarity results for the first surrogates for all D x D channels
    % ...
    % CVals(ParamSurro.Number+1,:,:) correlation-stationarity results for the (ParamSurro.Number)-th surrogates for all D x D channels    
    % Here CVals(1,i,j)=CVals(1,j,i) 

% FVals
    % Matrix of dimension [(ParamSurro.Number+1) x D]
    % FVals(1,:) frequency-stationarity results for the original D channels.
    % FVals(2,:) ,:) frequency-stationarity results for the first surrogates for all D
    % ...
    % FVals(ParamSurro.Number+1,:) ,:) frequency-stationarity results for the (ParamSurro.Number)-th surrogates for all D channels

% AVals
    % Matrix of dimension [(ParamSurro.Number+1) x D]
    % AVals(1,:) amplitude-stationarity results for the original D channels.
    % AVals(2,:) ,:) amplitude-stationarity results for the first surrogates for all D
    % ...
    % AVals(ParamSurro.Number+1,:) ,:) amplitude-stationarity results for the (ParamSurro.Number)-th surrogates for all D channels

% SHypo
    % Symmetric matrix of dimension [D x D]
    % The (i,j)-th element is 1, if the stationarity test 
    % was rejected for the channel pair with index i and j. 
    % If the stationarity test was not rejected for the pair 
    % (i,j), the element is 0.

     
% Technical remark:
% If you read through the source code, you will find that we sometimes 
% transpose the data matrix so that it becomes [M x D]. This is simply
% because the different algorithms expect different formats of the data.
% Throughout the source code and comments, D always stands for the number
% of channels, and M always stands for the number of samples.
    
% Load exemplary data
Data =  ASR_LOAD(500,1);

% Set parameters
[ParamFilter ParamN ParamL ParamS ParamSurro] = ASR_Setparameters;

% Detrend and filter the data
fs = 512;  % Sampling rate in Hz.
Data=ASR_Filter(Data, fs, ParamFilter);    

% Run the calculations
 % Randomness test
 [UVals UHypo] = ASR_N_Shell(Data,ParamN,ParamSurro);
 % Nonlinear independence test
 [BVals BHypo]= ASR_L_Shell(Data,ParamL,ParamSurro); 
 % Stationarity test
 % As in Ref[1], we increase the number of surrogates for the stationarity test
 ParamSurro.Number = 99;
 [CVals AVals FVals SHypo]= ASR_S_Shell(Data,ParamS,ParamSurro);
 
    

