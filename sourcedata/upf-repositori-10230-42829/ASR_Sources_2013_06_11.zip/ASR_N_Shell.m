function [UVals UHypo] = ASR_N_Shell(Data,ParamN,ParamSurro)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html 
% for further specifications and conditions of use. 

% References 
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012

D=size(Data,1);
for kkk = 1:D
    Data(kkk,:) = (Data(kkk,:)-mean(Data(kkk,:)))/std(Data(kkk,:));
end
DataSur = Data;

UVals =  zeros(ParamSurro.Number+1,D);

for Di = 1:ParamSurro.Number+1
    fprintf('N Surrog %i ',Di);
    % if Di == 1 the data is not replaced by a surrogate
    % rather the original is used
    if Di > 1
        for kkk = 1:D
            DataSur(kkk,:) = ASR_SurrogateUni(Data(kkk,:),ParamSurro);
        end
    end
    tic
    [UVals(Di,:)]= ASR_N(DataSur(:,1:ParamN.dsf:end),ParamN);
    toc
end

UHypo = zeros(D,1);
for kkk = 1:D
    if UVals(1,kkk) < min(UVals(2:end,kkk))
        UHypo(kkk) = 1;
    end
end