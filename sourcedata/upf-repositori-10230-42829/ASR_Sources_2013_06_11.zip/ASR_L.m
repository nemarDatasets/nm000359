function [L] = ASR_L(Data,ParamL)
% This source code forms part of the resources published along with
% Reference [1]. Please refer to http://www.dtic.upf.edu/~ralph/sc/index.html 
% for further specifications and conditions of use. 

% For a reference that describe this particular algorithm please refer to [2]
% and references therein.

% References 
% [1] Andrzejak RG, Schindler K and Rummel C, Phys. Rev. E 86, 046206, 2012
% [2] Chicharro D and Andrzejak RG, Phys. Rev. E, 80, 026217, 2009


Data = Data';
M = size(Data,1);
D = size(Data,2);
Lj= zeros(D,D);
L = zeros(D,D);


m = ParamL.m;
tau = ParamL.tau;
W = ParamL.Theiler;
k = ParamL.k;
embwin = (m-1)*tau;
Neff = M -embwin;

fprintf('m %i ',m);
fprintf('t %i M %i Ch %i',tau, M,D);


% Ncorrected(counter) is the effective number of distances in row/colum
% #counter of the distance matrix. Here the Theiler correction that skipps
% W data points has to be taken into account

Ncorrected = zeros(1,Neff);
Ncorrected(1:Neff) = Neff-(W*2+1);
for counter = 1:W
    Ncorrected(counter) = Neff-W-(counter);
    Ncorrected(Neff-counter+1) = Neff-W-(counter);
end;


% Allocate matrices
Hdistances =zeros(Neff,Neff,D,'single');
Hranks = zeros(Neff,Neff,D,'int16');
Hindexes = zeros(Neff,Neff,D,'int16');

% Determine distance matrices
for counter3 = 1:D
    for counter1 = embwin+1:embwin+1+tau
        for counter2 = counter1+1+W:M
            distA = 0;
            
            for index = -embwin:tau:0;
                distA = distA+(Data(counter1+index,counter3)-Data(counter2+index,counter3))^2; % X
            end
            Hdistances(counter1-embwin,counter2-embwin,counter3)=distA;
            Hdistances(counter2-embwin,counter1-embwin,counter3)=distA;
        end
    end
    for counter1 = embwin+2+tau:M
        for counter2 = counter1+1+W:M
            Hdistances(counter1-embwin,counter2-embwin,counter3)= Hdistances(counter1-embwin-tau,counter2-embwin-tau,counter3)-(Data(counter1-embwin-tau,counter3)-Data(counter2-embwin-tau,counter3))^2+(Data(counter1,counter3)-Data(counter2,counter3))^2;
            Hdistances(counter2-embwin,counter1-embwin,counter3)=Hdistances(counter1-embwin,counter2-embwin,counter3);
        end
    end
    
    
    
end

% overwrite zeros that were skipped due to the Theiler correction with an
% arbitrary high number. IMPORTANT: This number must be higher than the
% highest distance expected in the distance matrix
highnumber = 1e99;
Hdistances(Hdistances==0)=highnumber;

for counter3 =1:D
    % Calculate the matrices of ranks
    % Note that we here use the same way to determine the ranks like Matlab
    % does for example in the function ranksum.m
    
    [~, Hindexes(:,:,counter3)] = sort(Hdistances(:,:,counter3));
    N1 = 1:Neff;
    for s = 1:Neff
        Hranks(Hindexes(:,s,counter3),s,counter3) = N1;
    end
end


help1 = zeros(1,Neff);
for counter = 1:Neff
    help1(counter) = (Ncorrected(counter)+1)/2;
end
help2 = (k+1)/2;

for j = 1:Neff
    for counter3 = 1:D
        for counter4 = [1:counter3-1 counter3+1:D]
            Lj(counter3,counter4) = Lj(counter3,counter4)+(help1(j)-sum(Hranks(Hindexes(1:k,j,counter4),j,counter3))/k)/(help1(j)-help2);
        end
    end
end
L = Lj/Neff;


